package com.offlinecast.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class MyHttpServer(private val context: Context) : NanoHTTPD(8080) {

    private val placeholder: ByteArray by lazy {
        val bmp = Bitmap.createBitmap(16, 9, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.BLACK)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 50, out)
        bmp.recycle()
        out.toByteArray()
    }

    override fun serve(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
        return when (session.uri) {
            "/", "/index.html" -> serveIndex()
            "/stream" -> serveFrame()
            "/audio" -> serveAudio()
            else -> noCache(
                NanoHTTPD.newFixedLengthResponse(
                    NanoHTTPD.Response.Status.NOT_FOUND,
                    "text/plain",
                    "Not found"
                )
            )
        }
    }

    private fun serveIndex(): NanoHTTPD.Response {
        return try {
            val html = context.assets.open("index.html").use { String(it.readBytes(), Charsets.UTF_8) }
            noCache(
                NanoHTTPD.newFixedLengthResponse(
                    NanoHTTPD.Response.Status.OK,
                    "text/html; charset=utf-8",
                    html
                )
            )
        } catch (e: Exception) {
            NanoHTTPD.newFixedLengthResponse(
                NanoHTTPD.Response.Status.INTERNAL_ERROR,
                "text/plain",
                "index.html missing"
            )
        }
    }

    private fun serveFrame(): NanoHTTPD.Response {
        val bytes = ScreenService.latestFrame ?: placeholder
        val resp = NanoHTTPD.newFixedLengthResponse(
            NanoHTTPD.Response.Status.OK,
            "image/jpeg",
            ByteArrayInputStream(bytes),
            bytes.size.toLong()
        )
        return noCache(resp)
    }

    private fun serveAudio(): NanoHTTPD.Response {
        val resp = NanoHTTPD.newChunkedResponse(
            NanoHTTPD.Response.Status.OK,
            "audio/wav",
            AudioInputStream()
        )
        return noCache(resp)
    }

    private fun noCache(resp: NanoHTTPD.Response): NanoHTTPD.Response {
        resp.addHeader("Cache-Control", "no-cache, no-store, must-revalidate")
        resp.addHeader("Pragma", "no-cache")
        resp.addHeader("Expires", "0")
        return resp
    }
}

// Endless WAV stream: header first, then live audio chunks from AudioHub.
private class AudioInputStream : InputStream() {
    private val queue = AudioHub.register()
    private var current: ByteArray? = AudioHub.wavHeader()
    private var pos = 0

    @Volatile
    private var closed = false
    private val silence = ByteArray(4096)

    override fun read(): Int {
        val one = ByteArray(1)
        val n = read(one, 0, 1)
        return if (n <= 0) -1 else (one[0].toInt() and 0xFF)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (closed) return -1
        var chunk = current
        if (chunk == null || pos >= chunk.size) {
            chunk = try {
                queue.poll(200, TimeUnit.MILLISECONDS)
            } catch (e: InterruptedException) {
                null
            }
            if (closed) return -1
            if (chunk == null) chunk = silence
            current = chunk
            pos = 0
        }
        val c: ByteArray = chunk ?: return -1
        val n = minOf(len, c.size - pos)
        System.arraycopy(c, pos, b, off, n)
        pos += n
        return n
    }

    override fun close() {
        closed = true
        AudioHub.unregister(queue)
    }
}
