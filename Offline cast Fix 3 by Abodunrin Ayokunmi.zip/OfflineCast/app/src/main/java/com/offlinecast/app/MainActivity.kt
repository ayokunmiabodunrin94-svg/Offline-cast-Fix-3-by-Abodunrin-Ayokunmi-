package com.offlinecast.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import fi.iki.elonen.NanoHTTPD
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

class MainActivity : Activity() {

    companion object {
        const val DEFAULT_URL = "http://192.168.173.56:8080"

        @Volatile
        var currentUrl: String = DEFAULT_URL

        private const val PORT = 8080
        private const val REQ_CAPTURE = 1001
        private const val REQ_NOTIFICATIONS = 1002
        private const val REQ_AUDIO = 1003
        private var server: MyHttpServer? = null
    }

    private lateinit var tvUrl: TextView
    private lateinit var ivQr: ImageView
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = getString(R.string.app_name)
        window.statusBarColor = Color.parseColor("#0E1627")
        window.navigationBarColor = Color.parseColor("#0B1222")

        val btnHotspot = findViewById<Button>(R.id.btnHotspot)
        val btnRefresh = findViewById<Button>(R.id.btnRefresh)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)
        tvUrl = findViewById(R.id.tvUrl)
        ivQr = findViewById(R.id.ivQr)
        val tvInstructions = findViewById<TextView>(R.id.tvInstructions)
        tvStatus = findViewById(R.id.tvStatus)
        val rowHow = findViewById<View>(R.id.rowHow)
        val tvHowArrow = findViewById<TextView>(R.id.tvHowArrow)

        rowHow.setOnClickListener {
            val show = tvInstructions.visibility != View.VISIBLE
            tvInstructions.visibility = if (show) View.VISIBLE else View.GONE
            tvHowArrow.text = if (show) "Hide" else "Show"
        }

        tvInstructions.text =
            "HOW TO CONNECT (Samsung TV fix):\n\n" +
            "1. Tap STEP 1 and turn ON Mobile Hotspot.\n" +
            "2. Also turn ON Mobile Data, then connect the TV to your hotspot.\n" +
            "3. Come back here and tap REFRESH ADDRESS. The link above shows your phone's real hotspot address (it can differ between phones).\n" +
            "4. On the TV browser open that exact link (or scan the QR code). " +
            "Keep Mobile Data ON for about 5 seconds so the TV allows the browser.\n" +
            "5. Tap STEP 2: START MIRRORING and allow screen capture.\n" +
            "6. Once the picture shows on the TV, you can turn Mobile Data OFF. " +
            "The stream keeps running locally and uses less than 1 MB of data.\n" +
            "7. Tap the TV screen for fullscreen.\n\n" +
            "8. For SOUND: allow the microphone prompt when you tap START MIRRORING (it is only used to capture the phone's own audio), then tap ENABLE SOUND on the TV page. Needs Android 10+, and some apps block audio capture. Sound can lag the picture by 1 to 3 seconds.\n\n" +
            "Keep this app open while casting. Tap STOP when you are done."

        requestNotificationPermissionIfNeeded()
        startServer()
        refreshAddress(false)

        btnHotspot.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            } catch (e: ActivityNotFoundException) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        btnRefresh.setOnClickListener { refreshAddress(true) }

        btnStart.setOnClickListener {
            startServer()
            if (Build.VERSION.SDK_INT >= 29 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            } else {
                launchCapture()
            }
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, ScreenService::class.java))
            tvStatus.postDelayed({ updateStatus() }, 400)
            Toast.makeText(this, "Mirroring stopped", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO) {
            // Start mirroring whether or not audio was allowed (no audio if denied).
            launchCapture()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAddress(false)
        updateStatus()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                refreshAddress(false)
                val svc = Intent(this, ScreenService::class.java).apply {
                    putExtra(ScreenService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenService.EXTRA_DATA, data)
                }
                startForegroundService(svc)
                tvStatus.postDelayed({ updateStatus() }, 900)
                Toast.makeText(this, "Mirroring started. Open " + currentUrl + " on the TV", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateStatus() {
        if (ScreenService.isRunning) {
            tvStatus.text = "Casting live"
            tvStatus.setBackgroundResource(R.drawable.bg_pill_live)
            tvStatus.setTextColor(Color.parseColor("#3DDC97"))
        } else {
            tvStatus.text = "Idle"
            tvStatus.setBackgroundResource(R.drawable.bg_pill_idle)
            tvStatus.setTextColor(Color.parseColor("#93A3C4"))
        }
    }

    private fun refreshAddress(showToast: Boolean) {
        val ip = findHotspotIp()
        currentUrl = if (ip != null) "http://$ip:$PORT" else DEFAULT_URL
        tvUrl.text = currentUrl
        try {
            ivQr.setImageBitmap(makeQr(currentUrl, 512))
        } catch (e: Exception) {
            // ignore QR failure
        }
        if (showToast) {
            val msg = if (ip != null) "Address: $currentUrl"
            else "No hotspot detected. Turn Hotspot ON, then tap REFRESH ADDRESS."
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun findHotspotIp(): String? {
        var best: String? = null
        var fallback: String? = null
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (nif in Collections.list(interfaces)) {
                if (!nif.isUp || nif.isLoopback) continue
                val name = nif.name.lowercase()
                for (addr in Collections.list(nif.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (name.startsWith("ap") || name.startsWith("swlan") ||
                            name.startsWith("rndis") || name.startsWith("wlan1")
                        ) {
                            if (best == null) best = ip
                        } else if (addr.isSiteLocalAddress &&
                            !name.startsWith("rmnet") && !name.startsWith("ccmni") &&
                            !name.startsWith("tun") && !name.startsWith("dummy") &&
                            !name.startsWith("v4-")
                        ) {
                            if (fallback == null) fallback = ip
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return best ?: fallback
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        }
    }

    private fun startServer() {
        val current = server
        if (current != null && current.isAlive) return
        try {
            val s = MyHttpServer(applicationContext)
            s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            server = s
        } catch (e: IOException) {
            Toast.makeText(this, "Could not start server on port 8080", Toast.LENGTH_LONG).show()
        }
    }

    private fun makeQr(text: String, size: Int): Bitmap {
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val w = matrix.width
        val h = matrix.height
        val pixels = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                pixels[y * w + x] = if (matrix.get(x, y)) Color.BLACK else Color.WHITE
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && !ScreenService.isRunning) {
            server?.stop()
            server = null
        }
    }
}
