package com.offlinecast.app

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue

object AudioHub {
    const val SAMPLE_RATE = 44100
    private const val CHANNELS = 2
    private const val BITS = 16
    private const val MAX_QUEUED_CHUNKS = 32

    private val clients = CopyOnWriteArrayList<LinkedBlockingQueue<ByteArray>>()

    fun register(): LinkedBlockingQueue<ByteArray> {
        val q = LinkedBlockingQueue<ByteArray>(MAX_QUEUED_CHUNKS)
        clients.add(q)
        return q
    }

    fun unregister(q: LinkedBlockingQueue<ByteArray>) {
        clients.remove(q)
    }

    fun publish(data: ByteArray) {
        for (q in clients) {
            if (!q.offer(data)) {
                q.poll()
                q.offer(data)
            }
        }
    }

    // WAV header for an endless PCM stream (sizes set to maximum).
    fun wavHeader(): ByteArray {
        val byteRate = SAMPLE_RATE * CHANNELS * BITS / 8
        val blockAlign = CHANNELS * BITS / 8
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray(Charsets.US_ASCII))
        b.putInt(-1)
        b.put("WAVE".toByteArray(Charsets.US_ASCII))
        b.put("fmt ".toByteArray(Charsets.US_ASCII))
        b.putInt(16)
        b.putShort(1)
        b.putShort(CHANNELS.toShort())
        b.putInt(SAMPLE_RATE)
        b.putInt(byteRate)
        b.putShort(blockAlign.toShort())
        b.putShort(BITS.toShort())
        b.put("data".toByteArray(Charsets.US_ASCII))
        b.putInt(-1)
        return b.array()
    }
}
