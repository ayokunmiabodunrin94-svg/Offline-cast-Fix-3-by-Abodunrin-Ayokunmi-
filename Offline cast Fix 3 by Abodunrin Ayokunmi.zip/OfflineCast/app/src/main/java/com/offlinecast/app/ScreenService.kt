package com.offlinecast.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import kotlin.math.max

class ScreenService : Service() {

    companion object {
        @Volatile
        var latestFrame: ByteArray? = null

        @Volatile
        var isRunning: Boolean = false

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"

        private const val CHANNEL_ID = "offline_cast_channel"
        private const val NOTIFICATION_ID = 1
        private const val FRAME_INTERVAL_MS = 80L
        private const val JPEG_QUALITY = 50
        private const val LONG_EDGE = 1280
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var reusableBitmap: Bitmap? = null
    private val jpegOut = ByteArrayOutputStream()

    private var currentW = 0
    private var currentH = 0
    private var currentDpi = 0
    private var displayManager: DisplayManager? = null

    @Volatile
    private var audioRunning = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) {
                handleResize()
            }
        }
    }

    private val captureRunnable = object : Runnable {
        override fun run() {
            grabFrame()
            handler?.postDelayed(this, FRAME_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()

        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startCapture(resultCode, data)
            isRunning = true
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Offline Cast", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Offline Cast Fix 3 by Abodunrin Ayokunmi - Casting to TV")
            .setContentText("Streaming at " + MainActivity.currentUrl)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun computeSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        currentDpi = metrics.densityDpi
        val scale = LONG_EDGE.toFloat() / max(metrics.widthPixels, metrics.heightPixels).toFloat()
        var w = (metrics.widthPixels * scale).toInt()
        var h = (metrics.heightPixels * scale).toInt()
        w -= w % 2
        h -= h % 2
        return Pair(w, h)
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        stopCapture()

        val t = HandlerThread("OfflineCastCapture")
        t.start()
        thread = t
        val h = Handler(t.looper)
        handler = h

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, h)
        projection = mp

        val size = computeSize()
        currentW = size.first
        currentH = size.second

        val reader = ImageReader.newInstance(currentW, currentH, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        virtualDisplay = mp.createVirtualDisplay(
            "OfflineCast",
            currentW, currentH, currentDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, h
        )

        displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
        displayManager?.registerDisplayListener(displayListener, h)

        if (Build.VERSION.SDK_INT >= 29) {
            startAudio(mp)
        }

        h.post(captureRunnable)
    }

    // Called when the phone rotates: resize the capture so landscape fills the TV.
    private fun handleResize() {
        val vd = virtualDisplay ?: return
        val size = computeSize()
        if (size.first == currentW && size.second == currentH) return
        try {
            val newReader = ImageReader.newInstance(size.first, size.second, PixelFormat.RGBA_8888, 2)
            vd.resize(size.first, size.second, currentDpi)
            vd.surface = newReader.surface
            val old = imageReader
            imageReader = newReader
            currentW = size.first
            currentH = size.second
            try { old?.close() } catch (e: Exception) { }
        } catch (e: Exception) {
            // keep the old size if resize fails
        }
    }

    @android.annotation.TargetApi(29)
    private fun startAudio(mp: MediaProjection) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AudioHub.SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                AudioHub.SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(max(minBuf, 8192) * 2)
                .setAudioPlaybackCaptureConfig(config)
                .build()
            rec.startRecording()
            audioRecord = rec
            audioRunning = true
            val t = Thread {
                val buf = ByteArray(4096)
                while (audioRunning) {
                    val n = try {
                        rec.read(buf, 0, buf.size)
                    } catch (e: Exception) {
                        -1
                    }
                    if (n > 0) {
                        AudioHub.publish(buf.copyOf(n))
                    } else if (n < 0) {
                        break
                    }
                }
            }
            t.isDaemon = true
            t.start()
            audioThread = t
        } catch (e: Exception) {
            audioRunning = false
        }
    }

    private fun stopAudio() {
        audioRunning = false
        try { audioRecord?.stop() } catch (e: Exception) { }
        try { audioRecord?.release() } catch (e: Exception) { }
        audioRecord = null
        audioThread = null
    }

    private fun grabFrame() {
        val reader = imageReader ?: return
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val bmpWidth = rowStride / pixelStride

            var bmp = reusableBitmap
            if (bmp == null || bmp.width != bmpWidth || bmp.height != image.height) {
                bmp?.recycle()
                bmp = Bitmap.createBitmap(bmpWidth, image.height, Bitmap.Config.ARGB_8888)
                reusableBitmap = bmp
            }
            buffer.rewind()
            bmp!!.copyPixelsFromBuffer(buffer)

            jpegOut.reset()
            if (bmpWidth == image.width) {
                bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, jpegOut)
            } else {
                val cropped = Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
                cropped.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, jpegOut)
                cropped.recycle()
            }
            latestFrame = jpegOut.toByteArray()
        } catch (e: Exception) {
            // skip this frame
        } finally {
            image?.close()
        }
    }

    private fun stopCapture() {
        stopAudio()
        try { displayManager?.unregisterDisplayListener(displayListener) } catch (e: Exception) { }
        displayManager = null
        handler?.removeCallbacksAndMessages(null)
        try { virtualDisplay?.release() } catch (e: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (e: Exception) { }
        imageReader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        thread?.quitSafely()
        thread = null
        handler = null
        reusableBitmap?.recycle()
        reusableBitmap = null
        latestFrame = null
    }

    override fun onDestroy() {
        isRunning = false
        stopCapture()
        stopForeground(true)
        super.onDestroy()
    }
}
